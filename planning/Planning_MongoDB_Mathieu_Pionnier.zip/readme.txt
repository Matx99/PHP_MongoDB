Etapes:

1) Utiliser Compass en local
2) Aller sur planning/init_databse.php pour initialiser la base de donn�es
3) Puis aller sur index.php

 
La liste des fonctionnalit�s d�velopp�es dans votre livraison et attendues dans le sujet:

- Toutes (cr�ation base de donn�es avec planning par semaine, 
affichage de cette base dans un tableau sur l'index, affichage en fonction de l'ann�e, 
mise � jour du planning possible, affichage des statistiques par ordre croissant...).

La liste des fonctionnalit�s attendues dans le sujet mais non d�velopp�es par vous. :

- Aucune

La liste des fonctionnalit�s qui vous sont personnelles :

- Page responsive

Pour chacune des fonctionnalit�s d�velopp�es, son niveau de finalisation (partiel/ finalis� / fiable /bug/...)

- Tout est finalis� mais lorsque l'on modifie un nom, il faut revenir sur la bonne ann�e (bouton "changer d'ann�e)
car la page s'actualise et revient � l'ann�e par d�faut (2019).

