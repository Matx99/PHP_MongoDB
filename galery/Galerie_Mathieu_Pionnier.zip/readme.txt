Etapes:

1) Utiliser Compass en local
2) Aller sur galery/index.php puis cr�er un album pour initialiser la base de donn�es

 
La liste des fonctionnalit�s d�velopp�es dans votre livraison et attendues dans le sujet:

- Toutes (cr�ation base de donn�es sans MySQL, drag and drop, carousel, ajout dans un album,
titre de galerie, date de creation, date de mise � jour...).

La liste des fonctionnalit�s attendues dans le sujet mais non d�velopp�es par vous. :

- Aucune

La liste des fonctionnalit�s qui vous sont personnelles :

- Suppression d'images venant d'un album
- Suppression d'un album
- Responsive

Pour chacune des fonctionnalit�s d�velopp�es, son niveau de finalisation (partiel/ finalis� / fiable /bug/...)

- Tout est finalis�.
